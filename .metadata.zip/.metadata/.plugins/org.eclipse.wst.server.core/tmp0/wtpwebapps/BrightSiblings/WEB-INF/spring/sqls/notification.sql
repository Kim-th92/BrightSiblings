drop sequence notiseq;
drop table notification;

create sqeunce notiseq;
create table notification(
	

);