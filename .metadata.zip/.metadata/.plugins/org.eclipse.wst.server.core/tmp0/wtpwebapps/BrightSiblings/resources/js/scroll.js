//Javascript
	var count = 0;
	//스크롤 바닥 감지
	window.onscroll = function(e) {
		//추가되는 임시 콘텐츠
		//window height + window scrollY 값이 document height보다 클 경우,
		if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
			//실행할 로직 (콘텐츠 추가)
			count++;
			var addContent = '<div class="feedWrap"><p>' + count
					+ '번째로 추가된 콘텐츠</p></div>';
			//article에 추가되는 콘텐츠를 append
			$('article id=newsFeed').append(addContent);
		}
	};